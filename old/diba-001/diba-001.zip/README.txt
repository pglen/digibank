Digital Bank

 Crypto currency. 
 
 How to make. 
 
  Windows.
  
	type 'makeall'
  
  Linux.

  type 'make'
  
  
  
Files:

block_blue2.c       Block encryption
bluemac.h           Macros for bluepoint
bluepoint2.c        
bluepoint2.h        
diba.h              
dibadec.c           
dibagen.c           Generate token
dibapow.c           Proof of work feasability
digibank.c		    Feas ability study for digibank
hs_crypt.c          Test encryption
Makefile
README.txt          This file
test_blue2.c

